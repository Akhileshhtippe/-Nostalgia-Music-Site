"use client";

import { track } from "@vercel/analytics";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Track = {
  id: string;
  title: string;
  artist: string;
  film: string;
  year: number;
  duration: number;
  videoId: string;
};

type Playlist = {
  id: string;
  name: string;
  tracks: Track[];
};

type YouTubePlayer = {
  playVideo: () => void;
  pauseVideo: () => void;
  nextVideo?: () => void;
  previousVideo?: () => void;
  loadVideoById: (videoId: string) => void;
  getCurrentTime: () => number;
  getDuration: () => number;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  destroy: () => void;
};

type YouTubeAPI = {
  Player: new (element: HTMLElement, options: {
    videoId: string;
    playerVars?: Record<string, number | string>;
    events?: {
      onReady?: () => void;
      onStateChange?: (event: { data: number }) => void;
      onError?: (event: { data: number }) => void;
    };
  }) => YouTubePlayer;
  PlayerState: {
    PLAYING: number;
    PAUSED: number;
    ENDED: number;
  };
};

declare global {
  interface Window {
    YT?: YouTubeAPI;
    onYouTubeIframeAPIReady?: () => void;
  }
}

const NEEDS_VIDEO_ID = "REPLACE_WITH_YOUR_VIDEO_ID";

// One line per song: replace only the metadata/videoId with a rights-cleared YouTube upload.
const PLAYLISTS: Playlist[] = [
  {
    id: "cassette-evenings",
    name: "Cassette Evenings",
    tracks: [
      { id: "track-01", title: "Your rights-cleared track", artist: "Your artist", film: "Your film", year: 1996, duration: 242, videoId: NEEDS_VIDEO_ID },
      { id: "track-02", title: "Another rights-cleared track", artist: "Your artist", film: "Your film", year: 1997, duration: 218, videoId: NEEDS_VIDEO_ID },
    ],
  },
  {
    id: "monsoon-radio",
    name: "Monsoon Radio",
    tracks: [
      { id: "track-03", title: "Rain on the Radio", artist: "Your artist", film: "Your film", year: 1994, duration: 251, videoId: NEEDS_VIDEO_ID },
      { id: "track-04", title: "Balcony Lights", artist: "Your artist", film: "Your film", year: 1998, duration: 230, videoId: NEEDS_VIDEO_ID },
    ],
  },
  {
    id: "Sunday-matinee",
    name: "Sunday Matinee",
    tracks: [
      { id: "track-05", title: "Sunday Afternoon", artist: "Your artist", film: "Your film", year: 1995, duration: 263, videoId: NEEDS_VIDEO_ID },
      { id: "track-06", title: "Last Bus Home", artist: "Your artist", film: "Your film", year: 1999, duration: 226, videoId: NEEDS_VIDEO_ID },
    ],
  },
];

const GLASS = "border border-white/10 bg-gradient-to-b from-white/[0.15] to-white/[0.055] backdrop-blur-3xl backdrop-saturate-[1.7] shadow-[0_16px_48px_-12px_rgba(0,0,0,0.8),inset_0_1px_0_rgba(255,255,255,0.2)]";

function loadYouTubeAPI(): Promise<YouTubeAPI> {
  if (typeof window === "undefined") return Promise.reject(new Error("Window unavailable"));
  if (window.YT) return Promise.resolve(window.YT);

  return new Promise((resolve) => {
    const previous = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      previous?.();
      if (window.YT) resolve(window.YT);
    };

    if (!document.querySelector("script[src='https://www.youtube.com/iframe_api']")) {
      const script = document.createElement("script");
      script.src = "https://www.youtube.com/iframe_api";
      script.async = true;
      document.head.appendChild(script);
    }
  });
}

function formatTime(value: number) {
  const seconds = Math.max(0, Math.floor(value || 0));
  const minutes = Math.floor(seconds / 60);
  const remainder = String(seconds % 60).padStart(2, "0");
  return `${minutes}:${remainder}`;
}

function SeekBar({ current, duration, onSeek }: { current: number; duration: number; onSeek: (ratio: number) => void }) {
  const progress = duration > 0 ? Math.min(1, Math.max(0, current / duration)) : 0;

  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const update = (clientX: number) => {
      const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
      onSeek(ratio);
    };
    update(event.clientX);
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      const rect = event.currentTarget.getBoundingClientRect();
      onSeek(Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width)));
    }
  };

  return (
    <div
      aria-label="Seek"
      className="seek-hit flex h-6 w-full cursor-pointer items-center"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      role="slider"
      aria-valuemin={0}
      aria-valuemax={duration || 0}
      aria-valuenow={current}
      tabIndex={0}
      style={{ "--progress": `${progress * 100}%` } as React.CSSProperties}
    >
      <div className="seek-rail">
        <div className="seek-fill" />
        <div className="seek-knob" />
      </div>
    </div>
  );
}

function Transport({ playing, onPrevious, onToggle, onNext, mobile = false }: { playing: boolean; onPrevious: () => void; onToggle: () => void; onNext: () => void; mobile?: boolean }) {
  const button = mobile ? "grid min-h-11 min-w-11 place-items-center rounded-full" : "grid size-10 place-items-center rounded-full";
  return (
    <div className="flex items-center justify-center gap-1">
      <button className={`${button} text-white/75 transition hover:bg-white/10 hover:text-white`} onClick={onPrevious} aria-label="Previous track">
        <span aria-hidden>‹‹</span>
      </button>
      <button
        className={`${mobile ? "size-[52px]" : "size-11"} grid place-items-center rounded-full bg-gradient-to-b from-[var(--accent)] to-[var(--accent-deep)] text-black ring-1 ring-white/25 shadow-[0_8px_24px_color-mix(in_srgb,var(--accent)_42%,transparent)] transition hover:brightness-110 active:scale-95`}
        onClick={onToggle}
        aria-label={playing ? "Pause" : "Play"}
      >
        <span className="translate-x-px text-lg font-bold" aria-hidden>{playing ? "Ⅱ" : "▶"}</span>
      </button>
      <button className={`${button} text-white/75 transition hover:bg-white/10 hover:text-white`} onClick={onNext} aria-label="Next track">
        <span aria-hidden>››</span>
      </button>
    </div>
  );
}

function TrackMeta({ track }: { track: Track }) {
  return (
    <div className="min-w-0">
      <p className="truncate text-[15px] font-semibold text-white">{track.title}</p>
      <p className="truncate text-[12.5px] text-white/70">{track.artist} · {track.film} · {track.year}</p>
    </div>
  );
}

function YouTubeArtwork({ videoId, containerRef, playing, mobile = false }: { videoId: string; containerRef: React.RefObject<HTMLDivElement | null>; playing: boolean; mobile?: boolean }) {
  return (
    <div
      className={`youtube-slot relative shrink-0 overflow-hidden rounded-full bg-black/70 ring-2 ring-white/15 shadow-[0_10px_30px_rgba(0,0,0,.45)] ${mobile ? "size-16" : "size-20"}`}
    >
      <div
        className="vinyl-ring pointer-events-none absolute inset-0 z-10 rounded-full"
        style={{ "--spin-state": playing ? "running" : "paused" } as React.CSSProperties}
      />
      <div ref={containerRef} className="absolute inset-0 z-0 overflow-hidden rounded-full" />
      <div className="pointer-events-none absolute left-1/2 top-1/2 z-20 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-black/70 ring-2 ring-white/40" />
      {!videoId || videoId === NEEDS_VIDEO_ID ? (
        <div className="absolute inset-0 z-30 grid place-items-center bg-[radial-gradient(circle_at_center,#806447,#33261e_58%,#0b0908_59%)] p-2 text-center text-[9px] leading-tight text-white/65">
          <p className="font-semibold text-white/85">ADD VIDEO ID</p>
        </div>
      ) : null}
    </div>
  );
}

function PlaylistPicker({ playlists, activeId, onChange }: { playlists: Playlist[]; activeId: string; onChange: (id: string) => void }) {
  return (
    <div className="flex max-w-full gap-1 overflow-x-auto rounded-full border border-white/10 bg-black/20 p-1 backdrop-blur-md">
      {playlists.map((playlist) => (
        <button
          key={playlist.id}
          onClick={() => onChange(playlist.id)}
          className={`whitespace-nowrap rounded-full px-3 py-1.5 text-[11px] transition ${activeId === playlist.id ? "bg-white/15 text-white" : "text-white/55 hover:text-white"}`}
        >
          {playlist.name}
        </button>
      ))}
    </div>
  );
}

export function NostalgiaPlayer() {
  const [playlistId, setPlaylistId] = useState(PLAYLISTS[0].id);
  const [trackIndex, setTrackIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const playlist = useMemo(() => PLAYLISTS.find((item) => item.id === playlistId) ?? PLAYLISTS[0], [playlistId]);
  const playerRef = useRef<YouTubePlayer | null>(null);
  const artworkRef = useRef<HTMLDivElement | null>(null);
  const trackIndexRef = useRef(0);
  const playlistRef = useRef(playlist);

  useEffect(() => {
    trackIndexRef.current = trackIndex;
    playlistRef.current = playlist;
  }, [playlist, trackIndex]);

  const track = playlist.tracks[trackIndex] ?? playlist.tracks[0];


  const goToTrack = useCallback((nextIndex: number) => {
    const safeIndex = (nextIndex + playlist.tracks.length) % playlist.tracks.length;
    setTrackIndex(safeIndex);
    setCurrent(0);
    setDuration(playlist.tracks[safeIndex]?.duration ?? 0);
    setPlaying(false);
  }, [playlist.tracks]);

  const loadTrack = useCallback(async () => {
    if (!track.videoId || track.videoId === NEEDS_VIDEO_ID || !artworkRef.current) return;
    const YT = await loadYouTubeAPI();
    if (!artworkRef.current) return;

    if (playerRef.current) {
      playerRef.current.loadVideoById(track.videoId);
      return;
    }

    playerRef.current = new YT.Player(artworkRef.current, {
      videoId: track.videoId,
      playerVars: {
        playsinline: 1,
        controls: 1,
        rel: 0,
        modestbranding: 1,
      },
      events: {
        onReady: () => {
          setDuration(playerRef.current?.getDuration() || track.duration);
        },
        onStateChange: (event) => {
          if (!window.YT) return;
          if (event.data === window.YT.PlayerState.PLAYING) setPlaying(true);
          if (event.data === window.YT.PlayerState.PAUSED) setPlaying(false);
          if (event.data === window.YT.PlayerState.ENDED) {
            setPlaying(false);
            const nextIndex = (trackIndexRef.current + 1) % playlistRef.current.tracks.length;
            goToTrack(nextIndex);
          }
        },
        onError: (event) => {
          track("youtube_player_error", { code: String(event.data), videoId: track.videoId });
          const nextIndex = (trackIndexRef.current + 1) % playlistRef.current.tracks.length;
          goToTrack(nextIndex);
        },
      },
    });
  }, [goToTrack, track, trackIndex]);

  useEffect(() => {
    if (!track.videoId || track.videoId === NEEDS_VIDEO_ID) return;
    void loadTrack();
  }, [loadTrack, track.videoId]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      if (playerRef.current && playing) {
        const next = playerRef.current.getCurrentTime();
        const nextDuration = playerRef.current.getDuration();
        setCurrent(next);
        if (nextDuration > 0) setDuration(nextDuration);
      }
    }, 400);
    return () => window.clearInterval(timer);
  }, [playing]);

  useEffect(() => {
    return () => playerRef.current?.destroy();
  }, []);

  const togglePlayback = () => {
    if (!playerRef.current) {
      void loadTrack();
      return;
    }
    if (playing) playerRef.current.pauseVideo();
    else playerRef.current.playVideo();
  };

  const seek = (ratio: number) => {
    const next = ratio * duration;
    setCurrent(next);
    playerRef.current?.seekTo(next, true);
  };

  const changePlaylist = (id: string) => {
    setPlaylistId(id);
    setTrackIndex(0);
    setCurrent(0);
    setPlaying(false);
    playerRef.current?.destroy();
    playerRef.current = null;
    artworkRef.current = null;
  };

  return (
    <div className="flex w-full max-w-xl flex-col items-center gap-2.5">
      <PlaylistPicker playlists={PLAYLISTS} activeId={playlist.id} onChange={changePlaylist} />

      <div className={`hidden w-full items-center gap-4 rounded-full p-3 pr-5 sm:flex ${GLASS}`}>
        <YouTubeArtwork videoId={track.videoId} containerRef={artworkRef} playing={playing} />
        <div className="min-w-0 flex-1">
          <TrackMeta track={track} />
          <div className="mt-1.5 flex items-center gap-2">
            <SeekBar current={current} duration={duration} onSeek={seek} />
            <span className="shrink-0 text-[10.5px] tabular-nums text-white/55">{formatTime(current)} / {formatTime(duration || track.duration)}</span>
          </div>
        </div>
        <Transport
          playing={playing}
          onPrevious={() => goToTrack(trackIndex - 1)}
          onToggle={togglePlayback}
          onNext={() => goToTrack(trackIndex + 1)}
        />
      </div>

      <div className={`w-full rounded-[26px] p-3.5 sm:hidden ${GLASS}`}>
        <div className="flex items-center gap-3">
          <YouTubeArtwork videoId={track.videoId} containerRef={artworkRef} playing={playing} mobile />
          <TrackMeta track={track} />
        </div>
        <div className="mt-2">
          <SeekBar current={current} duration={duration} onSeek={seek} />
        </div>
        <div className="mt-1 flex items-center justify-between gap-3">
          <span className="min-w-[70px] text-[10.5px] tabular-nums text-white/55">{formatTime(current)} / {formatTime(duration || track.duration)}</span>
          <Transport
            mobile
            playing={playing}
            onPrevious={() => goToTrack(trackIndex - 1)}
            onToggle={togglePlayback}
            onNext={() => goToTrack(trackIndex + 1)}
          />
          <span className="min-w-[70px]" aria-hidden />
        </div>
      </div>
    </div>
  );
}
