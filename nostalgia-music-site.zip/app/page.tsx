import { Analytics } from "@vercel/analytics/next";
import { SpeedInsights } from "@vercel/speed-insights/next";
import { Clock } from "./clock";
import { NostalgiaPlayer } from "./player";

export default function Page() {
  return (
    <main className="relative isolate flex min-h-dvh flex-1 flex-col items-center justify-between overflow-hidden">
      <div aria-hidden="true" className="hero-bg fixed inset-0 -z-20 bg-cover bg-center">
        <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-black/80" />
      </div>

      <div aria-hidden="true" className="grain pointer-events-none fixed inset-0 -z-10 opacity-30" />

      <header className="pointer-events-none fixed inset-x-0 z-20 text-xs text-white/75">
        <div className="safe-top-left pointer-events-auto absolute">
          <Clock />
        </div>
        <div className="safe-top-center absolute left-1/2 -translate-x-1/2 whitespace-nowrap">
          <span className="rounded-full border border-white/10 bg-black/20 px-3 py-1.5 backdrop-blur-md">
            <span className="mr-1.5 inline-block size-1.5 rounded-full bg-emerald-300 shadow-[0_0_10px_rgba(110,231,183,.8)]" />
            1,284 listening now
          </span>
        </div>
        <nav aria-label="Social links" className="safe-top-right pointer-events-auto absolute flex gap-4">
          <a className="transition hover:text-white" href="https://instagram.com" target="_blank" rel="noreferrer">Instagram</a>
          <a className="transition hover:text-white" href="https://x.com" target="_blank" rel="noreferrer">X</a>
        </nav>
      </header>

      <div className="safe-bottom fixed z-20 flex justify-center">
        <NostalgiaPlayer />
      </div>

      <Analytics />
      <SpeedInsights />
    </main>
  );
}

